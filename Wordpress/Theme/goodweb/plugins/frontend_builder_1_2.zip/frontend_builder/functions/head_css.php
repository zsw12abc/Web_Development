

<?php

$admin_optionsDB = $this->option();
$admin_options = $this->admin_controls;
$general_options = array();
if(array_key_exists('general', $admin_options) && array_key_exists('options', $admin_options['general']))
foreach ($admin_options['general']['options'] as $general_ctrl) {
	if(array_key_exists('type',$general_ctrl) && $general_ctrl['type'] != 'collapsible') {
		if(array_key_exists('name', $general_ctrl) && array_key_exists('std',$general_ctrl)) {
			
			$general_options[$general_ctrl['name']] = $general_ctrl['std'];
			foreach($admin_optionsDB as $optt) {
				if($optt->name == $general_ctrl['name']) {
					if(isset($optt->value)) {
						$general_options[$general_ctrl['name']] = $optt->value;
					}
					break;
				}
			}
		}
	}
	else {
		foreach ($general_ctrl['options'] as $collapsible_ctrl) {
			if(array_key_exists('name',$collapsible_ctrl)) {
				if(array_key_exists('name', $collapsible_ctrl) && array_key_exists('std',$collapsible_ctrl)) {
					
					$general_options[$collapsible_ctrl['name']] = $collapsible_ctrl['std'];
					foreach($admin_optionsDB as $optt) {
						if($optt->name == $collapsible_ctrl['name']) {
							if(isset($optt->value)) {
								$general_options[$collapsible_ctrl['name']] = $optt->value;
							}
							break;
						}
					}
				}
			}
		}
	}
}

$general_options['high_rezolution_margin'] = (int) $general_options['high_rezolution_margin'];
$general_options['high_rezolution_width'] = (int) $general_options['high_rezolution_width'];
$general_options['med_rezolution_margin'] = (int) $general_options['med_rezolution_margin'];
$general_options['med_rezolution_width'] = (int) $general_options['med_rezolution_width'];
$general_options['low_rezolution_margin'] = (int) $general_options['low_rezolution_margin'];
$general_options['low_rezolution_width'] = (int) $general_options['low_rezolution_width'];


$marg = 100*$general_options['high_rezolution_margin'] / $general_options['high_rezolution_width'];

$width1_2 = (100-$marg)/2;
$width1_3 = (100-2*$marg)/3;
$width2_3 = ((100-2*$marg)/3)*2+$marg;
$width1_4 = (100-3*$marg)/4;
$width3_4 = ((100-3*$marg)/4)*3+2*$marg;
$width1_5 = (100-4*$marg)/5;

// one third sidebar
$marg_s3 = $marg *100/$width2_3;
$width1_2_s3 = (100-$marg_s3)/2;
$width1_3_s3 = (100-2*$marg_s3)/3;
$width2_3_s3 = ((100-2*$marg_s3)/3)*2+$marg_s3;
$width1_4_s3 = (100-3*$marg_s3)/4;
$width3_4_s3 = ((100-3*$marg_s3)/4)*3+2*$marg_s3;
$width1_5_s3 = ((100-4*$marg_s3)/5);

//one forth sidebar
$marg_s4 = $marg *100/$width3_4;
$width1_2_s4 = (100-$marg_s4)/2;
$width1_3_s4 = (100-2*$marg_s4)/3;
$width2_3_s4 = ((100-2*$marg_s4)/3)*2+$marg_s4;
$width1_4_s4 = (100-3*$marg_s4)/4;
$width3_4_s4 = ((100-3*$marg_s4)/4)*3+2*$marg_s4;
$width1_5_s4 = ((100-4*$marg_s4)/5);


$output ='
<style>
.fbuilder_column.fbuilder_column-1-2 {
	width:'.$width1_2.'%;
	margin-left: '.$marg.'%;
}
.fbuilder_column.fbuilder_column-1-3 {
	width:'.$width1_3.'%;
	margin-left: '.$marg.'%;
}
.fbuilder_column.fbuilder_column-2-3 {
	width:'.$width2_3.'%;
	margin-left: '.$marg.'%;
}
.fbuilder_column.fbuilder_column-1-4 {
	width:'.$width1_4.'%;
	margin-left: '.$marg.'%;
}
.fbuilder_column.fbuilder_column-3-4 {
	width:'.$width3_4.'%;
	margin-left: '.$marg.'%;
}
.fbuilder_column.fbuilder_column-1-5 {
	width:'.$width1_5.'%;
	margin-left: '.$marg.'%;
}

#fbuilder_content_wrapper.fbuilder_content_one-third-left-sidebar,
#fbuilder_content_wrapper.fbuilder_content_one-third-right-sidebar {
	width:'.$width2_3.'%;
}
.fbuilder_sidebar.fbuilder_one-third-left-sidebar {
	width:'.$width1_3.'%;
	margin-right: '.$marg.'%;
}
.fbuilder_sidebar.fbuilder_one-third-right-sidebar  {
	width:'.$width1_3.'%;
}

#fbuilder_content_wrapper.fbuilder_content_one-third-left-sidebar .fbuilder_column.fbuilder_column-1-2,
#fbuilder_content_wrapper.fbuilder_content_one-third-right-sidebar .fbuilder_column.fbuilder_column-1-2 {
	width:'.$width1_2_s3.'%;
	margin-left: '.$marg_s3.'%;
}
#fbuilder_content_wrapper.fbuilder_content_one-third-left-sidebar .fbuilder_column.fbuilder_column-1-3,
#fbuilder_content_wrapper.fbuilder_content_one-third-right-sidebar .fbuilder_column.fbuilder_column-1-3 {
	width:'.$width1_3_s3.'%;
	margin-left: '.$marg_s3.'%;
}
#fbuilder_content_wrapper.fbuilder_content_one-third-left-sidebar .fbuilder_column.fbuilder_column-2-3,
#fbuilder_content_wrapper.fbuilder_content_one-third-right-sidebar .fbuilder_column.fbuilder_column-2-3 {
	width:'.$width2_3_s3.'%;
	margin-left: '.$marg_s3.'%;
}
#fbuilder_content_wrapper.fbuilder_content_one-third-left-sidebar .fbuilder_column.fbuilder_column-1-4,
#fbuilder_content_wrapper.fbuilder_content_one-third-right-sidebar .fbuilder_column.fbuilder_column-1-4 {
	width:'.$width1_4_s3.'%;
	margin-left: '.$marg_s3.'%;
}
#fbuilder_content_wrapper.fbuilder_content_one-third-left-sidebar .fbuilder_column.fbuilder_column-3-4,
#fbuilder_content_wrapper.fbuilder_content_one-third-right-sidebar .fbuilder_column.fbuilder_column-3-4 {
	width:'.$width3_4_s3.'%;
	margin-left: '.$marg_s3.'%;
}
#fbuilder_content_wrapper.fbuilder_content_one-third-left-sidebar .fbuilder_column.fbuilder_column-1-5,
#fbuilder_content_wrapper.fbuilder_content_one-third-right-sidebar .fbuilder_column.fbuilder_column-1-5 {
	width:'.$width1_5_s3.'%;
	margin-left: '.$marg_s3.'%;
}

#fbuilder_content_wrapper.fbuilder_content_one-fourth-left-sidebar,
#fbuilder_content_wrapper.fbuilder_content_one-fourth-right-sidebar {
	width:'.$width3_4.'%;
	float:left;
}
.fbuilder_sidebar.fbuilder_one-fourth-left-sidebar {
	width:'.$width1_4.'%;
	margin-right: '.$marg.'%;
}
.fbuilder_sidebar.fbuilder_one-fourth-right-sidebar  {
	width:'.$width1_4.'%;
}

#fbuilder_content_wrapper.fbuilder_content_one-fourth-left-sidebar .fbuilder_column.fbuilder_column-1-2,
#fbuilder_content_wrapper.fbuilder_content_one-fourth-right-sidebar .fbuilder_column.fbuilder_column-1-2 {
	width:'.$width1_2_s4.'%;
	margin-left: '.$marg_s4.'%;
}

#fbuilder_content_wrapper.fbuilder_content_one-fourth-left-sidebar .fbuilder_column.fbuilder_column-1-3,
#fbuilder_content_wrapper.fbuilder_content_one-fourth-right-sidebar .fbuilder_column.fbuilder_column-1-3 {
	width:'.$width1_3_s4.'%;
	margin-left: '.$marg_s4.'%;
}

#fbuilder_content_wrapper.fbuilder_content_one-fourth-left-sidebar .fbuilder_column.fbuilder_column-2-3,
#fbuilder_content_wrapper.fbuilder_content_one-fourth-right-sidebar .fbuilder_column.fbuilder_column-2-3 {
	width:'.$width2_3_s4.'%;
	margin-left: '.$marg_s4.'%;
}

#fbuilder_content_wrapper.fbuilder_content_one-fourth-left-sidebar .fbuilder_column.fbuilder_column-1-4,
#fbuilder_content_wrapper.fbuilder_content_one-fourth-right-sidebar .fbuilder_column.fbuilder_column-1-4 {
	width:'.$width1_4_s4.'%;
	margin-left: '.$marg_s4.'%;
}

#fbuilder_content_wrapper.fbuilder_content_one-fourth-left-sidebar .fbuilder_column.fbuilder_column-3-4,
#fbuilder_content_wrapper.fbuilder_content_one-fourth-right-sidebar .fbuilder_column.fbuilder_column-3-4 {
	width:'.$width3_4_s4.'%;
	margin-left: '.$marg_s4.'%;
}

#fbuilder_content_wrapper.fbuilder_content_one-fourth-left-sidebar .fbuilder_column.fbuilder_column-1-5,
#fbuilder_content_wrapper.fbuilder_content_one-fourth-right-sidebar .fbuilder_column.fbuilder_column-1-5 {
	width:'.$width1_5_s4.'%;
	margin-left: '.$marg_s4.'%;
}



';


$marg = 100*$general_options['med_rezolution_margin'] / $general_options['med_rezolution_width'];
$width1_2 = (100-$marg)/2;
$width1_3 = (100-2*$marg)/3;
$width2_3 = ((100-2*$marg)/3)*2+$marg;
$width1_4 = (100-3*$marg)/4;
$width3_4 = ((100-3*$marg)/4)*3+2*$marg;

$output .= '
@media screen and (max-width: '.$general_options['high_rezolution_width'].'px) {
	.fbuilder_column.fbuilder_column-1-2 {
		width:'.$width1_2.'%;
		margin-left: '.$marg.'%;
	}
	.fbuilder_column.fbuilder_column-1-3 {
		width:'.$width1_3.'%;
		margin-left: '.$marg.'%;
	}
	.fbuilder_column.fbuilder_column-2-3 {
		width:'.$width2_3.'%;
		margin-left: '.$marg.'%;
	}
	.fbuilder_column.fbuilder_column-1-4 {
		width:'.$width1_4.'%;
		margin-left: '.$marg.'%;
	}
	.fbuilder_column.fbuilder_column-3-4 {
		width:'.$width3_4.'%;
		margin-left: '.$marg.'%;
	}
	.fbuilder_column.fbuilder_column-1-5 {
		width:'.$width1_5.'%;
		margin-left: '.$marg.'%;
	}

}';


$marg = 100*$general_options['low_rezolution_margin'] / $general_options['low_rezolution_width'];
$width1_2 = (100-$marg)/2;
$width1_3 = (100-2*$marg)/3;
$width2_3 = ((100-2*$marg)/3)*2+$marg;
$width1_4 = (100-3*$marg)/4;
$width3_4 = ((100-3*$marg)/4)*3+2*$marg;

$output .= '
@media screen and (max-width: '.$general_options['med_rezolution_width'].'px) {
	.fbuilder_column.fbuilder_column-1-2 {
		width:'.$width1_2.'%;
		margin-left: '.$marg.'%;
	}
	.fbuilder_column.fbuilder_column-1-3 {
		width:'.$width1_3.'%;
		margin-left: '.$marg.'%;
	}
	.fbuilder_column.fbuilder_column-2-3 {
		width:'.$width2_3.'%;
		margin-left: '.$marg.'%;
	}
	.fbuilder_column.fbuilder_column-1-4 {
		width:'.$width1_4.'%;
		margin-left: '.$marg.'%;
	}
	.fbuilder_column.fbuilder_column-3-4 {
		width:'.$width3_4.'%;
		margin-left: '.$marg.'%;
	}
	.fbuilder_column.fbuilder_column-1-5 {
		width:'.$width1_5.'%;
		margin-left: '.$marg.'%;
	}

}';

$output .= '
@media screen and (max-width: '.$general_options['low_rezolution_width'].'px) {
	.fbuilder_column.fbuilder_column-1-2 {
		width:100%;
		margin-left: 0%;
	}
	.fbuilder_column.fbuilder_column-1-3 {
		width:100%;
		margin-left: 0%;
	}
	.fbuilder_column.fbuilder_column-2-3 {
		width:100%;
		margin-left: 0%;
	}
	.fbuilder_column.fbuilder_column-1-4 {
		width:100%;
		margin-left: 0%;
	}
	.fbuilder_column.fbuilder_column-3-4 {
		width:100%;
		margin-left: 0%;
	}
	.fbuilder_column.fbuilder_column-1-5 {
		width:100%;
		margin-left: 0%;
	}

}';

$output .= '
</style>
';

if(array_key_exists('css_custom', $general_options) && $general_options['css_custom'] != '') {
	$output .='
<style>
'.$general_options['css_custom'].'
</style>
';
}

?>