<?php
function map_google_shortcode_scripts() {
			wp_enqueue_script('maps_google_script', "http://maps.google.com/maps/api/js?sensor=true", array('jquery'),false,true);
			wp_enqueue_script('gmap3_script', TPSTRAP_URL.'js/gmap3.min.js', array('jquery'),false,true);
	}
	add_action( 'wp_enqueue_scripts', 'map_google_shortcode_scripts');


class FrontendBuilder {
	
	var $main, $path, $name, $url, $menu_controls, $shortcodes, $rows, $icons;
	
	function __construct($file) {
		$this->main = $file;
		$this->init();
		return $this;
	}
	
	
	
	function init() {
		$this->path = dirname( __FILE__ );
		$this->name = basename( $this->path );
		$this->url = plugins_url( "/{$this->name}/" );
		$this->admin_controls = $this->get_admin_controls();
		$this->menu_controls = $this->get_menu_controls();
		$this->shortcodes = $this->get_shortcodes();
		$this->rows = $this->get_rows();
		$this->icons = $this->get_icons();
		$this->showall = false;
		$this->yoast = false;

		define('FBUILDER_URL', $this->url);
		
		$this->activate();
		
		require_once($this->path .'/functions/shortcodes.php');
		$opt = $this->option('showall');
		if(!empty($opt) && $opt->value == 'true') {
			$this->showall = true;
			add_action('wp_ajax_nopriv_fbuilder_edit', array(&$this, 'ajax_edit'));
			add_action('wp_ajax_nopriv_fbuilder_shortcode', array(&$this, 'ajax_shortcode'));  
			add_action('wp_ajax_nopriv_fbuilder_pages', array(&$this, 'ajax_pages'));  
		}
		if( is_admin() ) {
			
			register_activation_hook( $this->main , array(&$this, 'activate') );
			
			add_action('admin_menu', array(&$this, 'admin_menu')); 
			
			add_action( 'init', array(&$this, 'global_admin_includes') );
			add_action('admin_head', array(&$this, 'admin_head')); 


			add_action('wp_ajax_fbuilder_check', array(&$this, 'ajax_check'));  
			add_action('wp_ajax_fbuilder_switch', array(&$this, 'ajax_switch'));  
			add_action('wp_ajax_fbuilder_shortcode', array(&$this, 'ajax_shortcode'));  
			add_action('wp_ajax_fbuilder_save', array(&$this, 'ajax_save'));  
			add_action('wp_ajax_fbuilder_pages', array(&$this, 'ajax_pages'));  
			add_action('wp_ajax_fbuilder_admin_save', array(&$this, 'ajax_admin_save'));  
			add_action('wp_ajax_fbuilder_edit', array(&$this, 'ajax_edit'));

			// Ajax calls
			add_theme_support( 'post-thumbnails' );
			
		}
		else {
			add_action('wp', array(&$this, 'refresh_variables'));
			add_action('wp_head', array(&$this, 'wp_head') );
			add_action('init', array(&$this, 'frontend_includes'));
			
			add_filter('the_content',array(&$this, 'replace_content'), 0);
		}
		add_action( 'fbuilder_head', array(&$this, 'edit_page_includes'));
		add_action('init', array(&$this, 'textdomain'));
		add_action( 'admin_bar_menu', array(&$this, 'admin_bar'),81 );
}
	function textdomain() {
  		load_plugin_textdomain( 'frontend-builder', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
	}
	function activate() {
		global $wpdb;
		$table_name = $wpdb->prefix . 'frontend_builder_pages';
	
		if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
			$fbuilder_pages_sql = "CREATE TABLE " . $table_name ." (
						  id mediumint(9) NOT NULL AUTO_INCREMENT,
						  switch text NOT NULL,
						  layout text NOT NULL,
						  items MEDIUMTEXT NOT NULL COLLATE utf8_general_ci,
						  PRIMARY KEY (id)
						);";	
	
			require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
			dbDelta($fbuilder_pages_sql);			
		}
		
	
		$table_name = $wpdb->prefix . 'frontend_builder_options';
	
		if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
			$fbuilder_options_sql = "CREATE TABLE " . $table_name ." (
			              id mediumint(9) NOT NULL AUTO_INCREMENT,
						  name text NOT NULL,
						  value text NOT NULL,
						  PRIMARY KEY (id)
						);";
	
			require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
			dbDelta($fbuilder_options_sql);			
		}
	
	}	
	
	function remove_shortcodes($shortcodes = false) {
		if (is_array($shortcodes)) {
			foreach($shortcodes as $sh) {
				if(array_key_exists($sh, $this->shortcodes)) {
					unset($this->shortcodes[$sh]);
				}
			}
		}
		else if(is_string($shortcodes)) {
			unset($this->shortcodes[$shortcodes]);
		}
		else
		 $this->shortcodes = array();
	}
	function add_new_shortcodes($sh) {
		if(is_array($sh)) {
			$this->shortcodes = array_merge($this->shortcodes, $sh);
		}
	}
	function refresh_variables() {
		$nav_menus = json_encode(get_registered_nav_menus());
		$this->shortcodes = str_replace('"wp_nav_menu_list"', $nav_menus, $this->shortcodes);
	}
	function admin_head(){
		if(array_key_exists('post', $_GET)) {
			$builder = $this->database($_GET['post'], true);
			echo '<script type="text/javascript">var fbuilderSwitch="'.$builder->switch.'";</script>';
		}
		
	}
	function admin_bar() {
		
		if ( is_admin() ) {
			$current_screen = get_current_screen();
			$post = get_post();
	
			if ( 'post' == $current_screen->base
				&& 'add' != $current_screen->action
				&& ( $post_type_object = get_post_type_object( $post->post_type ) )
				&& current_user_can( 'read_post', $post->ID )
				&& ( $post_type_object->public )
				&& ( $post_type_object->show_in_admin_bar ) )
			{
				$this->admin_bar_links($post->ID);
			} elseif ( 'edit-tags' == $current_screen->base
				&& isset( $tag ) && is_object( $tag )
				&& ( $tax = get_taxonomy( $tag->taxonomy ) )
				&& $tax->public )
			{
				$this->admin_bar_links($post->ID);
			}
		}
	
		else {
				
			if ( !is_super_admin() || !is_admin_bar_showing() )
				return;
			$current_object = get_queried_object();
			if (!empty($current_object) && !empty( $current_object->post_type ) && ( $post_type_object = get_post_type_object( $current_object->post_type ) ) && current_user_can( $post_type_object->cap->edit_post, $current_object->ID )) {
				$this->admin_bar_links($current_object->ID);
				return;
			}
			if(!get_post_type()) {
				echo '';
				return;
			}
			global $post;
			$this->admin_bar_links($post->ID);
		
		}
	}
	function admin_bar_links($id) {
		global $wp_admin_bar;
		$sw = $this->ajax_check($id);
		if(isset($sw) && $sw == 'on') {
			$wp_admin_bar->add_menu(
				array( 'id' => 'fbuilder_edit',
	            	'href' => admin_url().'admin-ajax.php?action=fbuilder_edit&p='.$id,
					'title' => '<span class="fbuilder_edit_icon"></span>',
					'meta' => array( 'title' => __('Edit In Frontend', 'frontend-builder'),)
	        	)
	    	);
		}
		else {
			$wp_admin_bar->add_menu(
				array( 'id' => 'fbuilder_edit',
	            	'href' => admin_url().'admin-ajax.php?action=fbuilder_edit&p='.$id.'&sw=on',
					'title' => '<span class="fbuilder_edit_icon"></span>',
					'meta' => array('title' => __('Activate Frontend Builder', 'frontend-builder'))
	        	)
	    	);
		}
	}
	
	function global_admin_includes(){
		wp_enqueue_style('fbuilder_admin_global', $this->url . 'css/admin_global.css');
		wp_enqueue_script('fbuilder_admin_global', $this->url . 'js/admin_global.js', array('jquery'), 1.0, true);
	    wp_enqueue_script( 'wp-color-picker');
	    wp_enqueue_style( 'wp-color-picker');
	}
	
	function admin_menu() {
		$menu = add_menu_page( 'Frontend Builder', 'Frontend Builder', 'manage_options', 'frontendbuilder', array(&$this, 'admin_page'));
		
		add_action('load-'.$menu, array(&$this, 'admin_menu_includes')); 
	}
	
	function admin_menu_includes() {
		/* general includes */
/*
		wp_enqueue_script('jquery');
		wp_enqueue_script('jquery-color');
		wp_enqueue_script('jquery-ui');
		wp_enqueue_script('jquery-ui-widget');
		wp_enqueue_script('jquery-ui-sortable');
		wp_enqueue_script('jquery-ui-draggable');
*/
		wp_enqueue_script('jquery-ui',T_JS . '/jquery-ui.js');
		
		/*
wp_enqueue_script('jquery-ui-slider');
		wp_enqueue_script('jquery-ui-accordion');
*/
		
		/* image includes */
		wp_enqueue_style('thickbox');
		wp_enqueue_script('thickbox');
		
		/* custom scrollbar includes */
		wp_enqueue_script('fbuilder_mousewheel_js', $this->url . 'js/jquery.mousewheel.min.js');
		wp_enqueue_script('fbuilder_mCustomScrollbar_js', $this->url . 'js/jquery.mCustomScrollbar.min.js');
		wp_enqueue_style('fbuilder_mCustomScrollbar_css', $this->url . 'css/jquery.mCustomScrollbar.css');
		
		/* colorpicker includes */
	    wp_enqueue_script( 'fbuilder_iris', $this->url . 'js/iris.min.js',array(), 1.0, true);
		
		/* interface */		
		wp_enqueue_style('fbuilder_admin_page_css', $this->url . 'css/admin_page.css');
		wp_enqueue_script('fbuilder_admin_page_js', $this->url . 'js/admin_page.js');
	}
	
	function frontend_includes() {
		/* general includes */
		/*	wp_enqueue_script('jquery');
			wp_enqueue_script('jquery-color');
			wp_enqueue_script('jquery-ui');
			wp_enqueue_script('jquery-ui-widget');
			wp_enqueue_script('jquery-ui-slider');
			wp_enqueue_script('jquery-ui-accordion');
			wp_enqueue_script('jquery-ui-sortable');
			wp_enqueue_script('jquery-ui-draggable');*/
		/* interface includes */
		//wp_enqueue_style('fbuilder_font-awesome_css', $this->url . 'css/font-awesome.css');
		wp_enqueue_style('fbuilder_fornt_css', $this->url . 'css/front.css');
	}
	
	function edit_page_includes() {
		wp_enqueue_script(array('jquery', 'editor', 'thickbox', 'media-upload'));
		/*
wp_enqueue_script('jquery-color');
		wp_enqueue_script('jquery-ui');
		wp_enqueue_script('jquery-ui-widget');
		wp_enqueue_script('jquery-ui-slider');
		wp_enqueue_script('jquery-ui-accordion');
		wp_enqueue_script('jquery-ui-sortable');
		wp_enqueue_script('jquery-ui-draggable');
*/
			
		/* admin css */
		wp_enqueue_style( 'colors' );
		wp_enqueue_style( 'ie' );
		wp_enqueue_script('utils');
		
		/* image includes */
		wp_enqueue_style('thickbox');
		wp_enqueue_script('thickbox');
		
		/* custom scrollbar includes */
		wp_enqueue_script('fbuilder_mousewheel_js', $this->url . 'js/jquery.mousewheel.min.js');
		wp_enqueue_script('fbuilder_mCustomScrollbar_js', $this->url . 'js/jquery.mCustomScrollbar.min.js');
		wp_enqueue_style('fbuilder_mCustomScrollbar_css', $this->url . 'css/jquery.mCustomScrollbar.css');
		
		/* colorpicker includes */
	    wp_enqueue_script( 'fbuilder_iris', $this->url . 'js/iris.min.js',array(), 1.0, true);
		
		/* interface includes */
		wp_enqueue_style('fbuilder_font-awesome_css', $this->url . 'css/font-awesome.css');
		wp_enqueue_style('fbuilder_fornt_css', $this->url . 'css/front.css');
		wp_enqueue_script('fbuilder_front_js', $this->url . 'js/front.js', array('jquery'),'1.0', true);
}
		
	function admin_page() {
		require_once($this->path . '/pages/admin_page.php');
	}
	
	function get_admin_controls() {
		$output = array();
		require_once($this->path .'/functions/admin_control_list.php');
		
		$optionsDB = $this->option();
		foreach($output as $skey => $section) {
			$controls = $section['options'];
			if(is_array($controls)) {
				foreach($controls as $ckey => $control) {
					if($control['type'] == 'collapsible') {
						foreach($control['options'] as $okey => $option) {
							if(array_key_exists('name',$option)) {
								$exists = false;
								foreach($optionsDB as $ind => $opt) {
									if($opt->name == $option['name']) {
										$exists =  true;
										$output[$skey]['options'][$ckey]['options'][$okey]['std'] = $optionsDB[$ind];
										unset($optionsDB[$ind]);
										break;
									}
								}
								if(!$exists && array_key_exists('std', $option)) {
									$this->option($option['name'], $option['std']);
								}
							}
						}
					}
					else {
						if(array_key_exists('name',$control)) {
							$exists = false;
							foreach($optionsDB as $ind => $opt) {
								if(isset($control['name']) && isset($opt->name) && $opt->name == $control['name']) {
									$exists =  true;
									if(array_key_exists($skey, $output) && array_key_exists('otpions', $output[$skey]) && array_key_exists($ckey, $output[$skey]['options']))
										$output[$skey]['options'][$ckey]['std'] = $optionsDB[$ind];
									unset($optionsDB[$ind]);
									break;
								}
							}
							if(!$exists && array_key_exists('std', $control)) {
								$this->option($control['name'], $control['std']);
							}
						}
					}
					
				}
			}
		}
		return $output;
	}
	function get_admin_hideifs($options) {
		$hideifs = array();
		foreach($options as $control) {
			
			if($control['type'] == 'collapsible') {
				foreach($control['options'] as $option) {
					if(array_key_exists('hide_if', $option)) {
						$hideifs[$option['name']] = $option['hide_if'];
					}
				}
			}
			else {
				if(array_key_exists('hide_if', $control)) {
					$hideifs[$control['name']] = $control['hide_if'];
				}
			}
		}
		return $hideifs;
	}
	function get_admin_control($arr) {
		global $builder_icons;
		$fbuilder_icons = $this->icons;
		require_once($this->path .'/functions/admin_controls.php');
		$ctrl = new fbuilderControl($arr);
		return $ctrl->html;
	}
	function get_menu_controls() {
		$output = '{}';
		require_once($this->path .'/functions/menu_controls.php');
		return $output;
	}
	
	function get_shortcodes() {
		$output = array();
		require_once($this->path .'/functions/shortcode_list.php');
		return $output;
	}
	
	function get_icons() {
		$output = array();
		require_once($this->path .'/functions/icon_list.php');
		return $output;
	}
	
	function get_rows() {
		$output = array();
		require_once($this->path .'/functions/row_list.php');
		return $output;
	}
	
	function get_shortcode($get) {
		if(array_key_exists('f',$get)) {
			$shortcode = '['.$get['f'];
			$content = '';
			if(array_key_exists('options',$get)) {
				$optArray = $get['options'];
				foreach($optArray as $name => $val) {
					// check for sortable elements
					if (!is_array($val)) {
						if($name == 'content') $content = str_replace('&quot;','"',$val);	
						else $shortcode .= ' '.$name.'="'.$val.'"';
					}
					else if(!empty($val)) {
						$sortableOpts = Array();
						$firstOpt = true;
						foreach($val['order'] as $pos => $id) {
							foreach($val['items'][$id] as $opt => $oval) {
								if($opt == 'content') {
									if($firstOpt) {
										$firstOpt = false;
										$content .= str_replace('&quot;','"',$oval);
									}
									else {
										$content .= '|'.str_replace('&quot;','"',$oval);
									}
									
								}
								else $sortableOpts[$opt] = (array_key_exists($opt,$sortableOpts) ? $sortableOpts[$opt].'|'.$oval : $oval);
							}
						}
						foreach($sortableOpts as $opt => $oval) {
							if($opt == 'content') $content = str_replace('&quot;','"',$oval);	
							else $shortcode .= ' '.$opt.'="'.$oval.'"';
						}
					}
				}
			}
			$shortcode .= ']'.$content.'[/'.$get['f'].']';
			return do_shortcode($shortcode);
		}
	}
	
	function get_google_fonts($json = false) {
		$current_date = getdate(date("U"));
		
		$current_date = $current_date['weekday'] . $current_date['month'] . $current_date['mday'] . $current_date['year'];
		
		if(!get_option('fbuilder_admin_webfonts')) {
			$file_get = wp_remote_fopen("http://www.shindiristudio.com/responder/fonts.txt");
			if (strlen($file_get)>100) {
				add_option('fbuilder_admin_webfonts', $file_get);
				add_option('fbuilder_admin_webfonts_date', $current_date);
			}
		}
		
		if(get_option('fbuilder_admin_webfonts_date') != $current_date || get_option('fbuilder_admin_webfonts_date') == '') {
			$file_get = wp_remote_fopen("http://www.shindiristudio.com/responder/fonts.txt");
			if (strlen($file_get)>100) {
				update_option('fbuilder_admin_webfonts', wp_remote_fopen("http://www.shindiristudio.com/responder/fonts.txt"));
				update_option('fbuilder_admin_webfonts_date', $current_date);
			}
		}
		
		
		$fontsjson = get_option('fbuilder_admin_webfonts');
		$decode = json_decode($fontsjson, true);
		if(!is_array($decode) || $fontsjson == '' || !isset($fontsjson)) {
			$fontFailList = '';
			require_once($this->path . '/functions/font_list.php');
			$fontsjson = $fontFailList;
			$decode = json_decode($fontsjson, true);
		}
			
		$webfonts = array();
		$webfonts['default'] = 'Default';
		foreach ($decode['items'] as $key => $value) {
			$item_family= $decode['items'][$key]['family'];
			$item_family_trunc =  str_replace(' ','+',$item_family);
			$webfonts[$item_family_trunc] = $item_family;
		}
		if ($json) return $fontsjson;
		return $webfonts;
	}
	
	function get_font_variants($optionName = false, $variants = false) {
		/*if($optionName == false) {
			$fontsjson = get_option('fbuilder_admin_webfonts');
			$decode = json_decode($fontsjson, true);
			if(!is_array($decode) || $fontsjson == '' || !isset($fontsjson)) {
				$fontFailList = '';
				require_once($this->path . '/pages/font_list.php');
				$fontsjson = $fontFailList;
				$decode = json_decode($fontsjson, true);
			}
			$vars = array();
			foreach ($decode['items'] as $key => $value) {
				$vars[$value['family']] =  $value['variants'];
			}
		}
		else {
			$font = str_replace('+',' ', $this->option($optionName)->value);
			if($font == 'default' || $font == '') return array('default' => 'Default');
			else if($variants != false && is_array($variants)) {
				if(array_key_exists($font, $variants)) {
					return $variants[$font];
				}
				else {
					return array('regular');
				}
			}
			else {
				$fontsjson = get_option('fbuilder_admin_webfonts');
				$decode = json_decode($fontsjson, true);
				if(!is_array($decode) || $fontsjson == '' || !isset($fontsjson)) {
					$fontFailList = '';
					require_once($this->path . '/pages/font_list.php');
					$fontsjson = $fontFailList;
					$decode = json_decode($fontsjson, true);
				}
				foreach ($decode['items'] as $key => $value) {
					if ($value['family'] == $font) {
						$vars = array();
						foreach($value['variants'] as $fvar) {
							$vars[$fvar] = $fvar;
						}
						return $vars;
						
					}
				}
			}
		}*/
	}
	
	function get_font_head() {
		$output = '';
		require_once($this->path .'/functions/font_head.php');
		return $output;
	}
	
	function get_head_css() {
		$output = '';
		require_once($this->path .'/functions/head_css.php');
		return $output;
	}
	
	function replace_content($content, $pid = 0) {
		if($content == '//builder-false') {
			$id = $pid;
			$locked = false;
		}
		else {
			global $post; 
			$id = $post->ID;
			$locked = post_password_required();
		}
		$builder = $this->database($id, true);
		
		$output = '';
		
		if($builder->switch == 'on' && !$locked ) {
			return $this->get_html($builder);
			return $output;
		}
		else {
			return $content;
		}
	}
	
	function get_html($builder){
		$html = '';
		$output = '
		<div id="fbuilder_wrapper"'.($builder->items == '{}' ? ' class="empty"' : '').'>';

		$sidebar = false;
		if($builder->items != '{}') {
			$items = json_decode(stripslashes($builder->items), true);
			if(array_key_exists('sidebar', $items) 
				&& array_key_exists('active', $items['sidebar'])
				&& array_key_exists('items', $items['sidebar']) 
				&& array_key_exists('type', $items['sidebar']) 
				&& $items['sidebar']['active'] == true) {
				$sidebar = $items['sidebar']['type'];
				$html = '<div class="fbuilder_sidebar fbuilder_'.$items['sidebar']['type'].' fbuilder_row" data-rowid="sidebar"><div class="fbuilder_column">';
				if(is_array($items['sidebar']['items'])) {
					
					foreach($items['sidebar']['items'] as $sh) {
						if(!is_null($items['items'][$sh])) {
							$html .= '<div class="fbuilder_module" data-shortcode="'.$items['items'][$sh]['slug'].'" data-modid="'.$sh.'">'.$this->get_shortcode($items['items'][$sh]).'</div>';
							//$html .= $this->get_shortcode($items['items'][$sh]);
							//$html .= '</div>';
						}
					}
					
				}
				$html .= '</div><div style="clear:both;"></div></div>';
			}
			
		}
		$output .= $html.'<div id="fbuilder_content_wrapper"'.($sidebar != false ? ' class="fbuilder_content_'.$sidebar.'"' : '').'><div id="fbuilder_content">';

		if($builder->items != '{}') {
			$rows = $this->rows;
			
			for($rowId = 0; $rowId<$items['rowCount']; $rowId++) {
				if(array_key_exists($rowId, $items['rowOrder']))
					$row = $items['rowOrder'][$rowId];
				else 
					$row = null;
				if(!is_null($row)) {
					$current = $items['rows'][$row];
					$html = $rows[$current['type']]['html'];
					$html = str_replace('%1$s',$row,$html);
					$html = str_replace('%2$s','',$html);
					
					foreach($current['columns'] as $colId => $shortcodes) {
						$columnInterface = '';
							foreach($shortcodes as $sh) {
							if(!is_null($items['items'][$sh])) {
								$columnInterface .= '<div class="fbuilder_module" data-shortcode="'.$items['items'][$sh]['slug'].'" data-modid="'.$sh.'">';
								$columnInterface .= $this->get_shortcode($items['items'][$sh]);
								$columnInterface .= '</div>';
							}
						}
						$html = str_replace('%'.($colId+3).'$s',$columnInterface,$html);
					}
					
					$output .= $html;
				}
			}
		}


		$output .= '</div><div style="clear:both"></div></div><div style="clear:both"></div></div>';

		return $output;
	}

	
	function refresh_shortcode_list() {
		$fbuilder_sidebars = array();
		$fbuilder_sidebar_std = '';
		foreach ( $GLOBALS['wp_registered_sidebars'] as $sidebar ) {
			if($fbuilder_sidebar_std == '') $fbuilder_sidebar_std = $sidebar['id'];
			$fbuilder_sidebars[$sidebar['id']] = ucwords( $sidebar['name'] );
		}
		if(array_key_exists('sidebar', $this->shortcodes))
		$this->shortcodes['sidebar']['options']['name']['options'] = $fbuilder_sidebars;
		$this->shortcodes['sidebar']['options']['name']['std'] = $fbuilder_sidebar_std;
	}
	
	function wp_head() {
		include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
		$this->yoast = is_plugin_active('wordpress-seo/wp-seo.php');

		$output = $this->get_font_head();
		$output .= $this->get_head_css();
		echo $output;
	}
	
	function ajax_shortcode() {
	
		if(array_key_exists('options',$_POST)) {
			$_POST['options'] = json_decode(stripslashes($_POST['options']),true);
		}
		echo $this->get_shortcode($_POST);
		die();
	}
	
	function ajax_save() {
		if(array_key_exists('json',$_POST)) {
			$id = (int)$_POST['id'];
			/*! CHANGE TP */
			update_post_meta($id, "goodweb_fbuilder_code", $_POST['json']);
			
			/* CHANGE TP END */
			if($this->option('save_overwrite')->value == 'true') {
				$my_post = array();
				$my_post['ID'] = $id;
				$my_post['post_content'] = $this->replace_content('//builder-false',$id);
				wp_update_post( $my_post );
			}
		
			echo 'success';
		}
		die();
	}
	
	function ajax_pages() {
		$pages = $this->database(false, true);
		$pages = (array) $pages;
		$obj = array();
		if(count($pages) > 0) {
			foreach($pages as $id => $page) {
				$page->title = get_the_title($page->id);
				if($page->title == '')
					$page->title = '(no-title : id='.$page->id.')';
				$page->items = stripslashes($page->items);
				if(!is_null(get_post((int)$page->id)))
					$obj[$page->id] = $page;
			}
		}
		echo json_encode($obj);
		die();
	}
	
	function ajax_edit() {
		header('X-Frame-Options: GOFORIT');
		require_once($this->path . '/pages/edit_page.php');
		die();
	}
	
	
	function ajax_admin_save(){
		if(array_key_exists('json', $_POST)) {
			global $wpdb;
			$table_name = $wpdb->prefix . 'frontend_builder_options';
			$rows = $wpdb->get_results('SELECT * FROM '.$table_name);
			foreach($_POST['json'] as $option => $value) {
				$exists = false;
				foreach($rows as $row) {
					if($row->name == $option) {
						if($row->value != $value)
							$this->option($option, $value, array($row));
						$exists = true;
						break;
					}
				}
				if(!$exists) {
						$this->option($option, $value, '!exists');
				}
			}
		}
		echo 'success';
		die();
	}
	
	function ajax_check($id = false) {
		if($id) {
			$builder = $this->database($id, true);
			return $builder->switch;
			
		}
		else if(array_key_exists('p',$_GET)) {
			$builder = $this->database($_GET['p'], true);
			echo $builder->switch;
		}
		die();
	}
	function ajax_switch($ret = false) {
		if(array_key_exists('p',$_GET) && array_key_exists('sw', $_GET)) {
			global $wpdb;
			$content = $wpdb->get_row("SELECT * FROM $wpdb->posts WHERE id = '" . $_GET['p'] . "'", 'ARRAY_A');
			if(array_key_exists('post_status', $content) && $content['post_status'] != 'auto-draft') {
				$this->database($_GET['p'], false, $_GET['sw']);
				if($ret) return;
				echo 'success';
			}
			else {
				echo 'You need to set the title and save post as draft first.';
			}
		}
		else {
			echo 'You need to set the title and save post as draft first.';
		}
		die();
	}
	
	function option($name = false, $value = false, $rows = false){
		global $wpdb;
		$table_name = $wpdb->prefix . 'frontend_builder_options';
		if(!$rows) $rows = $wpdb->get_results('SELECT * FROM '.$table_name. ($name ? ' WHERE name=\''.$name.'\'' : ''));
		if($rows != '!exists' && count($rows) != 0 ) {
			if($value) {
				$wpdb->update(
					$table_name,
					array(
						'value' => $value,
						'name' => $name),
					array('id' => $rows[0]->id),
					array(
						'%s',
						'%s'),
					array('%d')
				);
			}
			else if(!$name){
				return $rows;
			}
			else {
				return $rows[0];
			}
		}
		else {
			if($value) {
				$wpdb->insert(
					$table_name,
					array(
						'name' => $name,
						'value' => $value),
					array(
						'%s',
						'%s')					
					
				);
			}
			else {
				$output = new stdClass();
				$output->value = '';
				return $output;
			}
		}
	}
	
	function database($id = false, $get = false, $switch = false, $layout = false, $items = false) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'frontend_builder_pages';
		$rows = $wpdb->get_results('SELECT * FROM '.$table_name. ($id ? ' WHERE id='.$id : ''));
		/*! CHANGE TP */
		$items = get_post_meta($id,'goodweb_fbuilder_code');
		if(count($rows) != 0) {
			if($get) {
				if($id){
						if(!empty($items[0])){
							$wpdb->update(
								$table_name,
								array(
									'switch' => 'on',
									'layout' => 'full width',
									'items'=> empty($items[0]) ? '' : addslashes($items[0])),
								array( 'id' => $id ),
								array( 
									'%s',
									'%s',
									'%s'),
								array('%d')
							);
							$rows = $wpdb->get_results('SELECT * FROM '.$table_name. ($id ? ' WHERE id='.$id : ''));
						}
						else {
							//update_post_meta($id,'goodweb_fbuilder_code',$rows[0]->items);
						}
						//print_r($rows[0]);die;
					return $rows[0];
				}
				else
					return $rows;
			}
			else {
				if(!empty($items[0])){
					$wpdb->update(
						$table_name,
						array(
							'switch' => 'on',
							'layout' => 'full width',
							'items'=> empty($items[0]) ? '' : addslashes($items[0]) ),
						array( 'id' => $id ),
						array( 
							'%s',
							'%s',
							'%s'),
						array('%d')
					);
				}
			}
		}
		else {
			if($get) {
				$output = new stdClass();
				$output->items = '{}';
				$output->switch = 'off';
				$output->layout = 'full width';
				return $output;
			}
			else {
				$mycontent = wpautop(get_post_field('post_content', $id));
				$mycontent = str_replace( array("\n","\r","\r\n"), '', $mycontent );
				if(empty($mycontent)) {
					$mycontent = '{"rows":[{"type":0,"columns":[[0]]}],"rowCount":1,"rowOrder":[0],"items":[{"f":"fbuilder_text","slug":"text","options":{"content":"<img src=&quot;http://www.themepunch.com/goodweb/wp-content/themes/goodweb/images/assets/example_element.png&quot;>","autop":"true","align":"left","bot_margin":0}}]}';
				}
				else {
					$mycontent = '{"rows":[{"type":0,"columns":[[0]]}],"rowCount":1,"rowOrder":[0],"items":[{"f":"fbuilder_text","slug":"text","options":{"content":"'.str_replace('"','&qout;',$mycontent).'","autop":"true","align":"left","bot_margin":24}}]}';
				}
					$wpdb->insert(
						$table_name,
						array(
							'id' => $id,
							'switch' => 'on',
							'layout' => 'full width',
							'items'=> empty($items[0]) ? $mycontent : addslashes($items[0]) ),	
						array(
							'%d',
							'%s',
							'%s',
							'%s')					
					);
				//}
			}
		}
	}
	/* CHANGE TP END */
	
}//End Class
?>