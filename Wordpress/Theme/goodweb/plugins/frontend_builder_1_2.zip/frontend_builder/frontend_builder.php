<?php   
/*
Plugin Name: Goodweb Builder
Plugin URI: http://goodweb.themepunch.com/dark
Description: Design your web page with a simple drag and drop system. Based on Frontend Builder by br0.
Author: ThemePunch
Version: 1.2
Author URI: http://www.themepunch.com
*/
global $fbuilder;
if (!class_exists("FrontendBuilder")) {
	require_once dirname( __FILE__ ) . '/frontend_builder_class.php';	
	$fbuilder = new FrontendBuilder(__FILE__);
}
?>